import Content from "../Content";

const page: Content = {
  title: "Self Blaming",
  description: "It must be my fault",
  slug: "self-blaming",
  pages: [
    `
# Self Blaming 👁

If you're attributing a negative situation entirely to yourself, you're Self Blaming. You don't have to be responsible for every bad thing that happens. If you're getting caught in traffic and you're berating yourself for not leaving earlier, you're self-blaming.

Would you treat someone else this way?
`,

    `
# Examples

"My son is failing in school, I must be a bad parent."
`,
  ],
};

export default page;
